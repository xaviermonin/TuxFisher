/*
Projet: TuxFisher
Licence: GPLv2
Version: BETA
Auteur: Xavier Monin
Date: 03/06/2008
Site: http://www.tuxfisher.net
Mail: tuxfisher@free.fr
Description: Jeu d'arcade/reflexion 2D mettant en sc�ne le personnage Tux
Copyright 2008 - Xavier Monin - Tous droits r�serv�s
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <QtGui>
#include <iostream>
#include "gestionniveau_tuxfisher.h"
#include "definitions.h"

const char* VERSIONCARTE = "20080725";

gestionNiveau_TuxFisher::gestionNiveau_TuxFisher()
{
	numerocarte = -1; // Niveau actuel (commence � partir de 0)
	version = 0;
}

bool gestionNiveau_TuxFisher::sauvegarder()
{
	QFile fichier(recupererNomFichier());
	QDateTime date = QDateTime::currentDateTime();
	QByteArray bytearray_numerodeversion;
	if (fichier.open(QFile::WriteOnly))
	{
		char caract_difficulte;
		char caract_x;
		char caract_y;
		char caract_nb;
		fichier.write("[TuxFisher]");
		fichier.write(VERSIONCARTE);
		std::cerr << "Numero version: " << numeroversion;
		fichier.write((char*)&numeroversion, 2);
		fichier.write(nomniveau.toLatin1()+"\n");
		fichier.write(nomauteur.toLatin1()+"\n");
		caract_difficulte=niveaudifficulte;
		caract_nb=nomcarte.size();
		fichier.write(&caract_difficulte,1);
		fichier.write(&caract_nb,1);
		
		for (int count=0; count<caract_nb; count++)
		{
			caract_x=taillecarte.at(count).width();
			caract_y=taillecarte.at(count).height();
			fichier.write(&caract_x,1);
			fichier.write(&caract_y,1);
			fichier.write(nomcarte.at(count).toLatin1()+"\n");
			fichier.write(donnes.at(count));
		}
		fichier.close();
	}
	else
		return false;
	return true;
}

bool gestionNiveau_TuxFisher::nouveauNiveau(QString niveau, QString auteur)
{
	numerocarte= -1;
	nomniveau = niveau;
	nomauteur = auteur;
	nomcarte.clear();
	donnes.clear();
	taillecarte.clear();
	numeroversion = 0;
	return true;
}

bool gestionNiveau_TuxFisher::nouvelleCarte(QString carte, QSize taille, QByteArray donnescarte)
{
	if (carte.isEmpty())
		return false;
	if (taille.width()*taille.height() != donnescarte.size())
		return false;
	nomcarte << carte;
	taillecarte << taille;
	donnes << donnescarte;
	numerocarte=nomcarte.size()-1;
	return true;
}

bool gestionNiveau_TuxFisher::chargerFichier(QString fichier)
{
	QFile fichierniveau(fichier);
	if (!fichierniveau.open(QIODevice::ReadOnly))
	{
		erreur = QObject::tr("Le fichier %1 n'a pas �t� ouvert.").arg(fichier);
		return false;
	}
	int retour = chargerFichier(fichierniveau);
	
	fichierniveau.close();
	return retour;
}

bool gestionNiveau_TuxFisher::chargerFichier(QString niveau, QString auteur)
{
	QString nomfichier(nomrepertoire+niveau+"-"+auteur+".tf");
	int retour = chargerFichier(nomfichier);
	
	return retour;
}

bool gestionNiveau_TuxFisher::chargerFichier(QIODevice &fichierniveau)
{
	if (!fichierniveau.isOpen())
	{
		erreur = QObject::tr("Le fichier de la partie n'a pas �t� ouvert.");
		return false;
	}
	int nbcarte;
	char caract;
	QByteArray controle;
	
	numerocarte=-1;
	nomniveau.clear();
	nomcarte.clear();
	donnes.clear();
	taillecarte.clear();
	
	fichierniveau.seek(0);
	
	QString chaineclef = fichierniveau.read(11);
	if (chaineclef=="[TuxFisher]")
	{
		// Lit la version du niveau
		QString version = fichierniveau.read(8);
		if (version!=VERSIONCARTE)
		{
			erreur = QObject::tr("La version du niveau n'est pas support�e.");
			return false;
		}
		// Lit le numero de version
		fichierniveau.read((char*) &numeroversion, 2);
		// Lit le nom du niveau
		nomniveau = fichierniveau.readLine().simplified();
		if (nomniveau.isEmpty())
		{
			erreur = QObject::tr("Le niveau n'a pas de nom.");
			return false;
		}
		// Lit le nom de l'auteur
		nomauteur = fichierniveau.readLine().simplified();
		if (nomauteur.isEmpty())
		{
			erreur = QObject::tr("Le niveau n'a pas d'auteur.");
			return false;
		}
		// Lit le niveau de difficult� du niveau
		fichierniveau.read(&caract, 1);
		niveaudifficulte = (NIVEAU)caract;
		// Lit le nombre de cartes du niveau
		fichierniveau.read(&caract, 1);
		nbcarte = caract;
		// - Partie qui lit les noms de carte du niveau -
		for (int c=0; c<nbcarte; c++)
		{
			QSize taille;
			// Lit la taille d'une carte
			fichierniveau.read(&caract, 1);
			taille.setWidth(caract);
			fichierniveau.read(&caract, 1);
			taille.setHeight(caract);
			taillecarte << taille;
			int nboctets = taille.width()*taille.height();
			// Lit le nom d'une carte
			nomcarte << fichierniveau.readLine().simplified();
			// Lit les donn�es de la carte
			QByteArray octets(fichierniveau.read(nboctets));
			if (octets.size()!=nboctets)
			{
				erreur = QObject::tr("Les cartes du niveau n'ont pas pu �tre lu correctement.");
				return false;
			}
			donnes << octets;
		}
		if (nbcarte != nomcarte.size())
		{
			erreur = QObject::tr("Les cartes lues ne correspondent pas au nombre de cartes pr�sentes");
			return false;
		}
	}
	else
	{
		erreur = QObject::tr("Le fichier n'est pas un niveau %1.").arg(NOM_APPLICATION);
		return false;
	}
	numerocarte=0; // = 1 carte
	return true;
}

bool gestionNiveau_TuxFisher::supprimerCarte()
{
	if (nomcarte.size()>1) // Si plus d'une carte existe
	{
		nomcarte.removeAt(numerocarte);
		donnes.removeAt(numerocarte);
		taillecarte.removeAt(numerocarte);
		if (numerocarte>0)
		{
			numerocarte--;
			selectionnerCarte(numerocarte);
		}
		else
		{
			numerocarte = 0;
			selectionnerCarte(numerocarte);
		}
		return true;
	}
	else
		return false; // Pas assez de carte, donc rien � supprimer
}

bool gestionNiveau_TuxFisher::selectionnerCarte(int num)
{
	if (nomcarte.size()>num && num>=0)
	{
		numerocarte = num;
		return true;
	}
	else
		return false;
}

bool gestionNiveau_TuxFisher::chargerCarte(QByteArray carte)
{
	if (donnes.size()>=numerocarte)
	{
		donnes.replace(numerocarte, carte);
		return true;
	}
	return false;
}

bool gestionNiveau_TuxFisher::chargerCarte(QByteArray carte, QSize taille)
{
	if (donnes.size()>=numerocarte)
	{
		if (taille.width()*taille.height() != carte.size())
			return false;
		donnes.replace(numerocarte, carte);
		taillecarte.replace(numerocarte, taille);
		return true;
	}
	return false;
}

bool gestionNiveau_TuxFisher::changerNomCarte(QString nom)
{
	if (nomcarte.size()>=numerocarte)
		if (!nom.isEmpty())
		{
			nomcarte.replace(numerocarte, nom);
			return true;
		}
	return false;
}

bool gestionNiveau_TuxFisher::changerNomNiveau(QString nom)
{
	if (!nom.isEmpty())
	{
		nomniveau = nom;
		numeroversion=0; // Le fichier ne sera pas le m�me: remise a z�ro de la version
		return true;
	}
	return false;
}

// Et si je change le nom du niveau, je sauvegarde, et je reviens a l'ancien nom du niveau? = (remise a z�ro! BUG!)

bool gestionNiveau_TuxFisher::changerNomAuteur(QString nom)
{
	if (!nom.isEmpty())
	{
		nomauteur = nom;
		numeroversion=0; // Le fichier ne sera pas le m�me: remise a z�ro de la version
		return true;
	}
	return false;
}

bool gestionNiveau_TuxFisher::changerDifficulte(NIVEAU niv)
{
	niveaudifficulte=niv;
	return true;
}

bool gestionNiveau_TuxFisher::echangerCartes(int premier, int second)
{
	int indexselection=numerocarte; // Carte s�lectionn�e

	if (premier>=nomcarte.size() && premier<0)
		return false;
	if (second>=nomcarte.size() && second<0)
		return false;

	QString string_temp=nomcarte.at(premier);
	QSize size_temp=taillecarte.at(premier);
	QByteArray bytearray_temp=donnes.at(premier);

	nomcarte[premier]=nomcarte[second];
	taillecarte[premier]=taillecarte[second];
	donnes[premier]=donnes[second];

	nomcarte[second]=string_temp;
	taillecarte[second]=size_temp;
	donnes[second]=bytearray_temp;

	selectionnerCarte(indexselection); // On revient � la carte selectionn�e avant

	return true;
}

QByteArray gestionNiveau_TuxFisher::recupererDonnesCarte()
{
	if (donnes.size()<numerocarte)
		return donnes.at(0);
	else
		return donnes.at(numerocarte);
}

QSize gestionNiveau_TuxFisher::recupererTailleCarte()
{
	if (taillecarte.size()<numerocarte)
		return taillecarte.at(0);
	else
		return taillecarte.at(numerocarte);		
}

QString gestionNiveau_TuxFisher::recupererNomCarte()
{
	if (nomcarte.size()<numerocarte)
		return "";
	else
		return nomcarte.at(numerocarte);
}

// Fonction statique renvoyant les informations de tous les niveaux du r�pertoire maps
void gestionNiveau_TuxFisher::recupererInfosNiveaux(QStringList &liste_nomfichier,
	QStringList &liste_nomniveau, QList<NIVEAU> &liste_difficulte, QStringList &liste_nomauteur, QList<QStringList> &liste_nomcarte)
{
	QDir repertoire(nomrepertoire);
	QStringList liste_repertoire = repertoire.entryList((QStringList)"*.tf", QDir::Files);
	gestionNiveau_TuxFisher gestion;
	for (int i = 0; i < liste_repertoire.size(); ++i)
	{
		QString fichier(nomrepertoire+(QString)QDir::separator()+liste_repertoire.at(i));
		QStringList nomcartes;
		if(gestion.chargerFichier(fichier))
		{
			liste_nomfichier << fichier;
			liste_nomcarte << gestion.recupererListeNomCarte();
			liste_nomniveau << gestion.recupererNomNiveau();
			liste_difficulte << gestion.recupererDifficulte();
			liste_nomauteur << gestion.recupererNomAuteur();
		}
	}
}

QString gestionNiveau_TuxFisher::nomrepertoire="maps"+(QString)QDir::separator();
